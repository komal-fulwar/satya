import sys
from datetime import datetime
import time

sys.path.append('../')

from creds.clients_creds import creds
from alice.accounts.login import init_accounts
from alice.orders.place_trade import buy_trade, sell_trade

accounts = init_accounts(creds)
master_account = accounts[0]

ce_buy_strike = int(input("Enter CE Buy Strike Price: "))
date_entry = input("Enter CE Buy Expiry (i.e. 2017 7 1): ")
year, month, day = map(int, date_entry.split(' '))
ce_buy_expiry = datetime(year, month, day)
ce_buy_expiry = str(ce_buy_expiry.date())

pe_sell_strike = int(input("Enter PE Sell Strike Price: "))
date_entry = input("Enter PE Sell Expiry (i.e. 2017 7 1): ")
year, month, day = map(int, date_entry.split(' '))
pe_sell_expiry = datetime(year, month, day)
pe_sell_expiry = str(pe_sell_expiry.date())

buy_order_instruments = []

ce_buy_ins = master_account.alice.get_instrument_for_fno(exch="NFO", symbol="NIFTY", expiry_date=ce_buy_expiry, is_fut=False, strike=ce_buy_strike, is_CE = True)
buy_order_instruments.append([ce_buy_ins, "BUY"])

sell_order_instruments = []

pe_sell_ins = master_account.alice.get_instrument_for_fno(exch="NFO", symbol="NIFTY", expiry_date=pe_sell_expiry, is_fut=False, strike=pe_sell_strike, is_CE = False)
sell_order_instruments.append([pe_sell_ins, "SELL"])

if buy_trade(accounts, buy_order_instruments):
    print("Instruments Bought")
    time.sleep(1.5)
    if sell_trade(accounts, sell_order_instruments):
        print("Instruments Sold")