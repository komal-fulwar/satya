import os
from os import path

ROOT_DIR = path.join("./")
MENU_OPTIONS = path.join("menu_options")

print("NIFTY 50 Strategy")
print("[+] Enter 1 - CEPE Buy CEPE Sell (Execute Strategy)")
print("[+] Enter 2 - CEPE Sell CEPE Buy (Sqrf Strategy)")
print("[+] Enter 3 - CE Buy PE Sell")
print("[+] Enter 4 - CE Sell PE Buy")
menu_choice = int(input("[-] Enter your option: "))

if menu_choice == 1:
    os.chdir(MENU_OPTIONS)
    os.system(f"python cepe_buy_cepe_sell.py")
    exit()
if menu_choice == 2:
    os.chdir(MENU_OPTIONS)
    os.system(f"python cepe_sell_cepe_buy.py")
    exit()
if menu_choice == 3:
    os.chdir(MENU_OPTIONS)
    os.system(f"python ce_buy_pe_sell.py")
    exit()
if menu_choice == 4:
    os.chdir(MENU_OPTIONS)
    os.system(f"python ce_sell_pe_buy.py")
    exit()
else:
    print("Invalid Choice")