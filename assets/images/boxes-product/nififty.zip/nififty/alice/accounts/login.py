import threading
# from alice_blue import *
from pya3 import *

# Client class to handle the alice object creating and buy sell orders
class Client:
	def __init__(self, u, p, t, aid, ais, lsize, a_k):
		self.username = u
		self.password = p
		self.tfa = t
		self.api_id = aid
		self.api_secret = ais
		self.lot_size = lsize
		self.a_k = a_k
		# saving order ids
		self.order_ids = []

	def create_alice_object(self):
		# access_token = AliceBlue.login_and_get_access_token(
		# 	username=self.username,
		# 	password=self.password,
		# 	twoFA=self.tfa,
		# 	app_id=self.api_id,
		# 	api_secret=self.api_secret
		# 	)

		# self.alice = AliceBlue(username=self.username, password=self.password, access_token=access_token, master_contracts_to_download=['NFO', 'NSE'])
		self.alice = Aliceblue(user_id=self.username,api_key=self.a_k)
		self.alice.get_session_id()
		self.alice.get_contract_master("NFO")
		self.name = self.alice.get_profile()['accountName']
		print(f"# Profile Name: { self.name }")

def init_accounts(creds):
	# store active threads in this array
	threads = []
	# array to keep the instances of clients
	client_objects = []
	# object creation
	for cred in creds:
		client = Client(cred['username'], cred['password'], cred['2fa'], cred['api_app_id'], cred['api_app_secret'], cred['lot_size'], cred['api_key'])
		client_objects.append(client)

	# alice object creation
	for client in client_objects:
		thread = threading.Thread(target=client.create_alice_object, daemon=True)
		threads.append(thread)
		thread.start()

	# completion of threads
	for thread in threads:
		thread.join()

	return client_objects