import threading
# from alice_blue import *
from pya3 import *

class PlaceTrade():
	def __init__(self, client_object, instruments):
		self.client_object = client_object
		self.alice_object = client_object.alice
		self.instruments = instruments
		self.lot_size = self.client_object.lot_size

	def trade_details(self, type_):			
		if type_ == "buy":
			self.__place_buy_trade()
		elif type_ == "sell":
			self.__place_sell_trade()

	def __place_buy_trade(self):
		self.basket = []
		for instrument in self.instruments:
			if instrument[1] == "SELL":
				self.ins = {}
				self.ins["instrument"] = instrument[0]
				self.ins["order_type"] = OrderType.Market
				self.ins["quantity"] = 100
				self.ins["transaction_type"] = TransactionType.Sell
				self.ins["product_type"] = ProductType.Delivery
				self.basket.append(self.ins)
			elif instrument[1] == "BUY":
				self.ins = {}
				self.ins["instrument"] = instrument[0]
				self.ins["order_type"] = OrderType.Market
				self.ins["quantity"] = self.lot_size
				self.ins["transaction_type"] = TransactionType.Buy
				self.ins["product_type"] = ProductType.Delivery
				self.basket.append(self.ins)

		self.alice_object.place_basket_order(self.basket)
		print(f"# { self.client_object.name }: Buy")

	def __place_sell_trade(self):
		self.basket = []
		for instrument in self.instruments:
			if instrument[1] == "SELL":
				self.ins = {}
				self.ins["instrument"] = instrument[0]
				self.ins["order_type"] = OrderType.Market
				self.ins["quantity"] = self.lot_size
				self.ins["transaction_type"] = TransactionType.Sell
				self.ins["product_type"] = ProductType.Delivery
				self.basket.append(self.ins)
			elif instrument[1] == "BUY":
				self.ins = {}
				self.ins["instrument"] = instrument[0]
				self.ins["order_type"] = OrderType.Market
				self.ins["quantity"] = 100
				self.ins["transaction_type"] = TransactionType.Buy
				self.ins["product_type"] = ProductType.Delivery
				self.basket.append(self.ins)

		self.alice_object.place_basket_order(self.basket)
		print(f"# { self.client_object.name }: Sell")

def buy_trade(accounts, instruments):
	accounts_array = []
	threads = []
	for account in accounts:
		acc = PlaceTrade(account, instruments)
		accounts_array.append(acc)

	for account in accounts_array:
		thread = threading.Thread(target=account.trade_details, args=("buy",), daemon=True)
		threads.append(thread)
		thread.start()

	for thread in threads:
		thread.join()

	return True

def sell_trade(accounts, instruments):
	accounts_array = []
	threads = []
	for account in accounts:
		acc = PlaceTrade(account, instruments)
		accounts_array.append(acc)

	for account in accounts_array:
		thread = threading.Thread(target=account.trade_details, args=("sell",), daemon=True)
		threads.append(thread)
		thread.start()

	for thread in threads:
		thread.join()

	return True