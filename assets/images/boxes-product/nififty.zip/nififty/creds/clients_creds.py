creds = [


	# sahil creds
	{
		'username': '199159',
		'password': 'BJPP281099',
		'2fa': '1999',
		'api_app_id': 'AYo4aEUrWE',
		'api_app_secret': '9nyY8TUNHIVMbf9yEQYABvkUzXWNvdUT7P01vFVN65uSlLB6ZANS59EoXF5qAHd6',
		'api_key': 'rVgZnKOUcsqcmSTdP7DdnB72tGoyYGRR6BESZiEBHU1bLFpTPMryzM5zYRhCqtK7vijBiFnKJUQFCrDZZIRH6LRm2cT4qpQg4PyNKDM9OyJXyUdIaupV7lfxS5n5HVdJ',
		'lot_size': 125,
	}

]
